Unrealscript Highlighter v.1.0

Created by Doug Clayton

To use this Unrealscript Highlighter in Notepad++:

1.	Open Notepad++
2.	Open the view menu and click on "User-Defined Dialogue..."
3.	Click import and browse to where you placed the "Unrealscript.xml" file.
4. 	It should say "import successful" and the unrealscript highlighter will be active for any ".uc" files.

